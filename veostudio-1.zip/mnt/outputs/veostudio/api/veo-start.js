/**
 * /api/veo-start.js
 * Serverless proxy to start a Google Veo 3.1 video generation.
 * Returns the long-running operation name for polling.
 */

export default async function handler(req, res) {
  // ── CORS ─────────────────────────────────────────────────────────────────
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Gemini-Key');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // ── Validate key ─────────────────────────────────────────────────────────
  const geminiKey = req.headers['x-gemini-key'];
  if (!geminiKey || geminiKey.length < 10) {
    return res.status(400).json({ error: 'Missing or invalid X-Gemini-Key header' });
  }

  // ── Proxy to Google Veo 3.1 ───────────────────────────────────────────────
  try {
    const endpoint =
      `https://generativelanguage.googleapis.com/v1beta/models/veo-3.1-generate-preview:generateVideos?key=${geminiKey}`;

    const upstream = await fetch(endpoint, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(req.body),
    });

    const data = await upstream.json();
    return res.status(upstream.status).json(data);
  } catch (err) {
    console.error('[veo-start proxy error]', err);
    return res.status(500).json({ error: 'Proxy error: ' + err.message });
  }
}
