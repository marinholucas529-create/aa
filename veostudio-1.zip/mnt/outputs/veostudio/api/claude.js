/**
 * /api/claude.js
 * Serverless proxy for Anthropic Claude API.
 * Receives the API key in the X-Claude-Key header so it never touches
 * the browser's network tab as a direct Anthropic call.
 */

export default async function handler(req, res) {
  // ── CORS ─────────────────────────────────────────────────────────────────
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Claude-Key');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // ── Validate key ─────────────────────────────────────────────────────────
  const claudeKey = req.headers['x-claude-key'];
  if (!claudeKey || claudeKey.length < 10) {
    return res.status(400).json({ error: 'Missing or invalid X-Claude-Key header' });
  }

  // ── Proxy to Anthropic ────────────────────────────────────────────────────
  try {
    const upstream = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'x-api-key': claudeKey,
        'anthropic-version': '2023-06-01',
        'content-type': 'application/json',
      },
      body: JSON.stringify(req.body),
    });

    const data = await upstream.json();
    return res.status(upstream.status).json(data);
  } catch (err) {
    console.error('[claude proxy error]', err);
    return res.status(500).json({ error: 'Proxy error: ' + err.message });
  }
}
