/**
 * /api/veo-poll.js
 * Serverless proxy to poll a Google Veo long-running operation.
 * Body: { "operationName": "operations/xxxxx" }
 */

export default async function handler(req, res) {
  // ── CORS ─────────────────────────────────────────────────────────────────
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Gemini-Key');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // ── Validate ──────────────────────────────────────────────────────────────
  const geminiKey = req.headers['x-gemini-key'];
  if (!geminiKey || geminiKey.length < 10) {
    return res.status(400).json({ error: 'Missing or invalid X-Gemini-Key header' });
  }

  const { operationName } = req.body;
  if (!operationName) {
    return res.status(400).json({ error: 'Missing operationName in body' });
  }

  // ── Poll Veo operation ────────────────────────────────────────────────────
  try {
    const endpoint =
      `https://generativelanguage.googleapis.com/v1beta/${operationName}?key=${geminiKey}`;

    const upstream = await fetch(endpoint, { method: 'GET' });
    const data = await upstream.json();
    return res.status(upstream.status).json(data);
  } catch (err) {
    console.error('[veo-poll proxy error]', err);
    return res.status(500).json({ error: 'Proxy error: ' + err.message });
  }
}
